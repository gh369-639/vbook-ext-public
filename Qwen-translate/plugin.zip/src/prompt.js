// prompt.js
// Quản lý prompt dịch thuật

// Cache các prompt đã load
var _promptCache = {};

// Prompt mặc định để dịch tiểu thuyết Trung → Việt
var DEFAULT_TRANSLATE_PROMPT =
    'Bạn là một dịch giả chuyên nghiệp, chuyên dịch tiểu thuyết Trung Quốc sang tiếng Việt.\n' +
    'Yêu cầu:\n' +
    '1. Giữ nguyên tên nhân vật, địa danh, danh hiệu (không phiên âm nếu có bảng tên)\n' +
    '2. Giữ nguyên định dạng: xuống dòng, đoạn văn\n' +
    '3. Sử dụng văn phong tự nhiên, phù hợp với thể loại (tiên hiệp, võ hiệp, ngôn tình...)\n' +
    '4. Chỉ xuất văn bản đã dịch, không giải thích, không thêm chú thích\n' +
    '5. Không dịch các ký tự đặc biệt như [name], {{var}}';

// Prompt cho auto-detect (không biết thể loại)
var DEFAULT_GENERAL_PROMPT =
    'You are a professional translator. Translate the following text to Vietnamese.\n' +
    'Requirements:\n' +
    '1. Keep proper nouns (names, places) consistent\n' +
    '2. Preserve formatting (line breaks, paragraphs)\n' +
    '3. Output only the translated text, no explanations';

// Lấy prompt theo tên
function getPromptByName(promptName) {
    if (!promptName) return null;

    // Kiểm tra cache
    if (_promptCache[promptName]) return _promptCache[promptName];

    // Thử đọc từ bộ nhớ cục bộ VBook (vb_prompt_<name>)
    try {
        var stored = getConfig('vb_prompt_' + promptName, '');
        if (stored) {
            _promptCache[promptName] = stored;
            return stored;
        }
    } catch(e) { /* ignore */ }

    return null;
}

// Lưu prompt vào cache
function setPromptCache(promptName, promptText) {
    if (promptName && promptText) {
        _promptCache[promptName] = promptText;
    }
}

// Xây dựng system prompt dựa vào config và danh sách tên
function buildSystemPrompt(nameCandidates) {
    var useLocName = parseInt2(getConfig('use_loc_name', 2), 2);
    var listprompts = parseLines(getConfig('listprompts', ''));

    // Thử lấy prompt từ danh sách prompt được cấu hình
    var customPrompt = null;
    for (var i = 0; i < listprompts.length; i++) {
        var p = getPromptByName(listprompts[i]);
        if (p) { customPrompt = p; break; }
    }

    var basePrompt = customPrompt || DEFAULT_TRANSLATE_PROMPT;

    // Thêm bảng tên vào prompt nếu lọc tên được bật và có tên
    if (useLocName === 1 && nameCandidates && Object.keys(nameCandidates).length > 0) {
        var nameList = Object.keys(nameCandidates).slice(0, 50); // Tối đa 50 tên
        basePrompt += '\n\nBảng tên nhân vật (không dịch, giữ nguyên hoặc dùng phiên âm Hán-Việt đã cho):';
        // Thêm phiên âm Hán-Việt cho mỗi tên
        var phienamDict = buildPhienamDict(nameList);
        nameList.forEach(function(name) {
            var phienam = phienamDict[name] || name;
            basePrompt += '\n- ' + name + ' → ' + phienam;
        });
    }

    return basePrompt;
}

// Xây dựng prompt để tạo prompt (model_Creat_Prompt)
function buildCreatePromptRequest(sampleText, genre) {
    return 'Hãy tạo một system prompt bằng tiếng Việt để dịch tiểu thuyết ' +
           (genre || 'Trung Quốc') + ' từ tiếng Trung sang tiếng Việt.\n' +
           'Prompt cần bao gồm: phong cách dịch, cách xử lý tên nhân vật, ' +
           'văn phong phù hợp với thể loại.\n' +
           'Văn bản mẫu:\n' + sampleText.substring(0, 500) + '\n\n' +
           'Chỉ xuất prompt, không giải thích.';
}

// Xóa cache prompt
function clearPromptCache() {
    _promptCache = {};
}
