// translate.js
// Entry point chính của plugin dịch Qwen
// Thay thế Gemini API bằng Qwen (Alibaba DashScope) - giữ nguyên tất cả tính năng

// ─── Main translate function (VBook gọi hàm này) ────────────────────────────

async function translate(text) {
    // Lấy config
    var apiKeys = parseLines(getConfig('api_keys', ''));
    if (apiKeys.length === 0) {
        return '[Lỗi] Chưa cấu hình Qwen API Key.\n' +
               'Vui lòng thêm API Key từ https://dashscope.aliyun.com vào mục cài đặt.';
    }

    var models    = parseLines(getConfig('modelsavecache',
        'qwen-plus\nqwen-max\nqwen-turbo\nqwen2.5-72b-instruct'));
    if (models.length === 0) models = ['qwen-plus'];

    var maxLength  = parseInt2(getConfig('max_length', 20000), 20000);
    var maxLine    = parseInt2(getConfig('max_line',    5000),  5000);

    var temperature = parseNum(getConfig('temp', 0.5), 0.5);
    var topP        = parseNum(getConfig('topP', 0.5), 0.5);
    var topK        = parseInt2(getConfig('topK', 20), 20);

    var opts = { temperature: temperature, topP: topP, topK: topK };

    // Tiền xử lý đầu vào
    text = preprocessInput(text);
    if (!text) return '';

    // Trích xuất tên ứng viên (nếu bật lọc tên)
    var nameCandidates = extractNameCandidates(text);

    // Xây dựng system prompt (có thể gồm bảng tên)
    var systemPrompt = buildSystemPrompt(nameCandidates);

    // Chia văn bản thành các chunk
    var chunks = splitIntoChunks(text, maxLength);

    var translatedChunks = [];
    var fromLang = getConfig('source_language', 'zh_CN') || source_language || 'zh_CN';
    var toLang   = getConfig('target_language',  'vi_VN') || target_language || 'vi_VN';

    for (var i = 0; i < chunks.length; i++) {
        var chunk = chunks[i];
        var translated;

        try {
            translated = await translateChunkWithQwen(chunk, systemPrompt, models, apiKeys, opts);
        } catch(qwenErr) {
            // Fallback 1: Baidu
            try {
                translated = await translateWithBaidu(chunk, fromLang, toLang);
            } catch(baiduErr) {
                // Fallback 2: Edge/Bing
                try {
                    translated = await translateWithEdge(chunk, fromLang, toLang);
                } catch(edgeErr) {
                    // Tất cả đều thất bại: trả về lỗi nhúng trong văn bản
                    translated = '[Lỗi dịch chunk ' + (i + 1) + ': ' +
                                 (qwenErr && qwenErr.message || String(qwenErr)) + ']';
                }
            }
        }

        // Hậu xử lý kết quả dịch từng chunk
        translated = postprocessOutput(translated);

        // Áp dụng phiên âm Hán-Việt cho tên chưa dịch được
        if (Object.keys(nameCandidates).length > 0) {
            var phienamDict = buildPhienamDict(Object.keys(nameCandidates));
            translated = applyPhienam(translated, phienamDict);
        }

        translatedChunks.push(translated);
    }

    // Nối các chunk
    var result = joinChunks(translatedChunks, chunks);

    // Áp dụng từ điển cơ bản (nếu bật)
    result = applyBasicDictIfEnabled(result);

    return result;
}
