// input.js
// Tiền xử lý văn bản đầu vào trước khi dịch

// Các ký tự đặc biệt cần được bảo vệ (không dịch)
var PROTECTED_PATTERNS = [
    { regex: /\[([^\]]+)\]/g,  tag: '__BRACKET__' },   // [text]
    { regex: /【([^】]+)】/g,  tag: '__JBRACKET__' },  // 【text】
    { regex: /\{\{([^}]+)\}\}/g, tag: '__DBRACES__' }  // {{text}}
];

// Tiền xử lý: làm sạch và chuẩn hóa văn bản
function preprocessInput(text) {
    if (!text) return '';

    // Chuẩn hóa xuống dòng
    text = text.replace(/\r\n/g, '\n').replace(/\r/g, '\n');

    // Xóa khoảng trắng thừa ở đầu/cuối dòng (giữ nguyên dòng trống)
    var lines = text.split('\n');
    lines = lines.map(function(line) { return line.trimRight(); });
    text = lines.join('\n');

    // Xóa nhiều dòng trống liên tiếp (giữ tối đa 2)
    text = text.replace(/\n{3,}/g, '\n\n');

    return text.trim();
}

// Hậu xử lý: làm sạch kết quả dịch
function postprocessOutput(text) {
    if (!text) return '';

    // Chuẩn hóa xuống dòng
    text = text.replace(/\r\n/g, '\n').replace(/\r/g, '\n');

    // Xóa các hậu tố không cần thiết mà model có thể thêm
    // Ví dụ: "---\nNote: ..." ở cuối bản dịch
    text = text.replace(/\n---\n.*$/s, '');
    text = text.replace(/\n_{3,}\n.*$/s, '');

    // Xóa header/footer mà model có thể thêm
    var lines = text.split('\n');
    // Bỏ dòng đầu nếu là "Here is the translation:" hoặc tương tự
    var skipFirst = /^(here is|translation:|bản dịch:|dịch:|translated?:)/i;
    if (lines.length > 1 && skipFirst.test(lines[0].trim())) {
        lines.shift();
        // Bỏ dòng trống ngay sau đó
        while (lines.length > 0 && lines[0].trim() === '') {
            lines.shift();
        }
    }
    // Bỏ dòng cuối nếu là ghi chú của model
    var skipLast = /^(note:|ghi chú:|lưu ý:|translator.?s note)/i;
    while (lines.length > 0 && skipLast.test(lines[lines.length - 1].trim())) {
        lines.pop();
        while (lines.length > 0 && lines[lines.length - 1].trim() === '') {
            lines.pop();
        }
    }

    return lines.join('\n').trim();
}

// Ước tính số token của văn bản (xấp xỉ: 1 token ≈ 1.5 ký tự CJK, 4 ký tự Latin)
function estimateTokens(text) {
    var cjkCount = (text.match(/[\u4e00-\u9fff\u3040-\u30ff\uac00-\ud7af]/g) || []).length;
    var otherCount = text.length - cjkCount;
    return Math.ceil(cjkCount / 1.5 + otherCount / 4);
}
