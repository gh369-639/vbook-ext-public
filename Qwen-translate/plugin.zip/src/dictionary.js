// dictionary.js
// Từ điển và xử lý tên nhân vật

// Cache từ điển đã parse
var _dictCache = null;
var _basicDictCache = null;

// Parse từ điển từ định dạng "nguồn=đích" (mỗi cặp trên một dòng)
function parseDictionary(dictText) {
    var dict = {};
    if (!dictText) return dict;
    var lines = String(dictText).split('\n');
    for (var i = 0; i < lines.length; i++) {
        var line = lines[i].trim();
        if (!line || line.startsWith('#') || line.startsWith('//')) continue;
        var eqIdx = line.indexOf('=');
        if (eqIdx < 1) continue;
        var src = line.substring(0, eqIdx).trim();
        var dst = line.substring(eqIdx + 1).trim();
        if (src && dst) {
            dict[src] = dst;
        }
    }
    return dict;
}

// Lấy từ điển cơ bản (vb_basic_dic)
function getBasicDict() {
    if (_basicDictCache) return _basicDictCache;
    var dictText = getConfig('vb_basic_dic', '');
    _basicDictCache = parseDictionary(dictText);
    return _basicDictCache;
}

// Lấy từ điển truyện (vb_story_dic - nếu có)
function getStoryDict() {
    var dictText = getConfig('vb_story_dic', '');
    return parseDictionary(dictText);
}

// Áp dụng từ điển vào văn bản (thay thế từ trái sang phải, dài nhất trước)
function applyDictionary(text, dict) {
    if (!text || !dict) return text;

    // Sắp xếp theo độ dài giảm dần để ưu tiên khớp dài hơn
    var keys = Object.keys(dict).sort(function(a, b) { return b.length - a.length; });

    for (var i = 0; i < keys.length; i++) {
        var src = keys[i];
        var dst = dict[src];
        if (!src) continue;
        // Thay thế tất cả occurrences
        var escaped = src.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        text = text.replace(new RegExp(escaped, 'g'), dst);
    }
    return text;
}

// Áp dụng từ điển cơ bản nếu được bật
function applyBasicDictIfEnabled(text) {
    var useBasicDic = parseInt2(getConfig('use_vb_basic_dic', 2), 2);
    if (useBasicDic !== 1) return text;
    var dict = getBasicDict();
    return applyDictionary(text, dict);
}

// Tạo danh sách tên nhân vật từ văn bản đầu vào
function extractNameCandidates(text) {
    var useLocName = parseInt2(getConfig('use_loc_name', 2), 2);
    if (useLocName !== 1) return {};

    var minLen    = parseInt2(getConfig('minname', 2), 2);
    var maxLen    = parseInt2(getConfig('maxname', 5), 5);
    var minRepeat = parseInt2(getConfig('repeatname', 10), 10);

    // Lấy stop words
    var stopWordsText = getConfig('vb_stopWord', '') + '\n' + getConfig('vb_stopWord_dic', '');
    var stopWords = {};
    parseLines(stopWordsText).forEach(function(w) { stopWords[w] = true; });

    // Đếm số lần xuất hiện của mỗi chuỗi ký tự Hán có độ dài phù hợp
    var pattern = new RegExp('[\u4e00-\u9fff]{' + minLen + ',' + maxLen + '}', 'g');
    var countMap = {};
    var match;
    while ((match = pattern.exec(text)) !== null) {
        var w = match[0];
        if (!stopWords[w]) {
            countMap[w] = (countMap[w] || 0) + 1;
        }
    }

    // Lọc lấy những chuỗi xuất hiện đủ nhiều lần
    var names = {};
    for (var w in countMap) {
        if (countMap.hasOwnProperty(w) && countMap[w] >= minRepeat) {
            names[w] = countMap[w];
        }
    }

    // Sắp xếp theo số lần xuất hiện (nhiều nhất trước)
    var sorted = Object.keys(names).sort(function(a, b) { return names[b] - names[a]; });
    var result = {};
    sorted.forEach(function(n) { result[n] = names[n]; });
    return result;
}

// Làm sạch cache từ điển (gọi khi config thay đổi)
function clearDictCache() {
    _dictCache = null;
    _basicDictCache = null;
}
