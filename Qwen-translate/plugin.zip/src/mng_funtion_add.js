// mng_funtion_add.js
// Các hàm tiện ích bổ sung

// Đọc giá trị config - hỗ trợ nhiều cách truy cập config trong VBook
function getConfig(key, defaultValue) {
    try {
        // Cách 1: vb_config object
        if (typeof vb_config !== 'undefined' && vb_config !== null) {
            var v = vb_config[key];
            if (v !== undefined && v !== null && v !== '') return v;
        }
        // Cách 2: config object
        if (typeof config !== 'undefined' && config !== null) {
            var v2 = config[key];
            if (v2 !== undefined && v2 !== null && v2 !== '') return v2;
        }
        // Cách 3: biến toàn cục với tên là key
        if (typeof globalThis !== 'undefined' && globalThis[key] !== undefined) {
            var v3 = globalThis[key];
            if (v3 !== null && v3 !== '') return v3;
        }
        // Cách 4: eval (fallback cuối cùng)
        try {
            var v4 = eval(key);
            if (v4 !== undefined && v4 !== null && v4 !== '') return v4;
        } catch(e2) { /* ignore */ }
    } catch(e) { /* ignore */ }
    return defaultValue !== undefined ? defaultValue : '';
}

// Phân tích chuỗi nhiều dòng thành mảng
function parseLines(str) {
    if (!str && str !== 0) return [];
    return String(str).split('\n')
        .map(function(s) { return s.trim(); })
        .filter(function(s) { return s.length > 0; });
}

// Parse số, trả về defaultValue nếu NaN
function parseNum(val, defaultValue) {
    var n = parseFloat(val);
    return isNaN(n) ? defaultValue : n;
}

// Parse số nguyên
function parseInt2(val, defaultValue) {
    var n = parseInt(val, 10);
    return isNaN(n) ? defaultValue : n;
}

// Xáo trộn mảng (Fisher-Yates)
function shuffleArray(arr) {
    var a = arr.slice();
    for (var i = a.length - 1; i > 0; i--) {
        var j = Math.floor(Math.random() * (i + 1));
        var tmp = a[i]; a[i] = a[j]; a[j] = tmp;
    }
    return a;
}

// Bỏ các ký tự trắng thừa, chuẩn hóa xuống dòng
function normalizeText(text) {
    if (!text) return '';
    return text.replace(/\r\n/g, '\n').replace(/\r/g, '\n').trim();
}

// Chia text thành mảng dòng
function splitLines(text) {
    return text.split('\n');
}

// Nối mảng dòng
function joinLines(lines) {
    return lines.join('\n');
}

// Kiểm tra một đoạn text có chứa ký tự CJK không
function hasCJK(text) {
    return /[\u4e00-\u9fff\u3400-\u4dbf\uf900-\ufaff]/.test(text);
}

// Trì hoãn (dùng trong async)
function delay(ms) {
    return new Promise(function(resolve) { setTimeout(resolve, ms); });
}

// Simple MD5 dùng cho Baidu sign
// Nguồn: đơn giản hóa từ md5.js public domain
function md5(string) {
    function safeAdd(x, y) {
        var lsw = (x & 0xFFFF) + (y & 0xFFFF);
        var msw = (x >> 16) + (y >> 16) + (lsw >> 16);
        return (msw << 16) | (lsw & 0xFFFF);
    }
    function bitRotateLeft(num, cnt) {
        return (num << cnt) | (num >>> (32 - cnt));
    }
    function md5cmn(q, a, b, x, s, t) {
        return safeAdd(bitRotateLeft(safeAdd(safeAdd(a, q), safeAdd(x, t)), s), b);
    }
    function md5ff(a, b, c, d, x, s, t) { return md5cmn((b & c) | (~b & d), a, b, x, s, t); }
    function md5gg(a, b, c, d, x, s, t) { return md5cmn((b & d) | (c & ~d), a, b, x, s, t); }
    function md5hh(a, b, c, d, x, s, t) { return md5cmn(b ^ c ^ d, a, b, x, s, t); }
    function md5ii(a, b, c, d, x, s, t) { return md5cmn(c ^ (b | ~d), a, b, x, s, t); }

    function md5blks(s) {
        var i, blks = [];
        for (i = 0; i < 64; i += 4) {
            blks[i >> 2] = s.charCodeAt(i) + (s.charCodeAt(i + 1) << 8) +
                (s.charCodeAt(i + 2) << 16) + (s.charCodeAt(i + 3) << 24);
        }
        return blks;
    }

    var m = [], i, hex = '', s = string,
        str = '', length8 = s.length * 8, result;
    s = unescape(encodeURIComponent(s));
    for (i = 0; i < s.length; i++) {
        m[i >> 2] |= s.charCodeAt(i) << ((i % 4) << 3);
    }
    m[s.length >> 2] |= 0x80 << ((s.length % 4) << 3);
    m[14 + (((s.length + 8) >> 6) << 4)] = length8;
    m[15 + (((s.length + 8) >> 6) << 4)] = Math.floor(length8 / 4294967296);

    var a = 1732584193, b = -271733879, c = -1732584194, d = 271733878;
    var n = m.length;
    for (i = 0; i < n; i += 16) {
        var olda = a, oldb = b, oldc = c, oldd = d;
        a = md5ff(a, b, c, d, m[i], 7, -680876936);
        d = md5ff(d, a, b, c, m[i + 1], 12, -389564586);
        c = md5ff(c, d, a, b, m[i + 2], 17, 606105819);
        b = md5ff(b, c, d, a, m[i + 3], 22, -1044525330);
        a = md5ff(a, b, c, d, m[i + 4], 7, -176418897);
        d = md5ff(d, a, b, c, m[i + 5], 12, 1200080426);
        c = md5ff(c, d, a, b, m[i + 6], 17, -1473231341);
        b = md5ff(b, c, d, a, m[i + 7], 22, -45705983);
        a = md5ff(a, b, c, d, m[i + 8], 7, 1770035416);
        d = md5ff(d, a, b, c, m[i + 9], 12, -1958414417);
        c = md5ff(c, d, a, b, m[i + 10], 17, -42063);
        b = md5ff(b, c, d, a, m[i + 11], 22, -1990404162);
        a = md5ff(a, b, c, d, m[i + 12], 7, 1804603682);
        d = md5ff(d, a, b, c, m[i + 13], 12, -40341101);
        c = md5ff(c, d, a, b, m[i + 14], 17, -1502002290);
        b = md5ff(b, c, d, a, m[i + 15], 22, 1236535329);
        a = md5gg(a, b, c, d, m[i + 1], 5, -165796510);
        d = md5gg(d, a, b, c, m[i + 6], 9, -1069501632);
        c = md5gg(c, d, a, b, m[i + 11], 14, 643717713);
        b = md5gg(b, c, d, a, m[i], 20, -373897302);
        a = md5gg(a, b, c, d, m[i + 5], 5, -701558691);
        d = md5gg(d, a, b, c, m[i + 10], 9, 38016083);
        c = md5gg(c, d, a, b, m[i + 15], 14, -660478335);
        b = md5gg(b, c, d, a, m[i + 4], 20, -405537848);
        a = md5gg(a, b, c, d, m[i + 9], 5, 568446438);
        d = md5gg(d, a, b, c, m[i + 14], 9, -1019803690);
        c = md5gg(c, d, a, b, m[i + 3], 14, -187363961);
        b = md5gg(b, c, d, a, m[i + 8], 20, 1163531501);
        a = md5gg(a, b, c, d, m[i + 13], 5, -1444681467);
        d = md5gg(d, a, b, c, m[i + 2], 9, -51403784);
        c = md5gg(c, d, a, b, m[i + 7], 14, 1735328473);
        b = md5gg(b, c, d, a, m[i + 12], 20, -1926607734);
        a = md5hh(a, b, c, d, m[i + 5], 4, -378558);
        d = md5hh(d, a, b, c, m[i + 8], 11, -2022574463);
        c = md5hh(c, d, a, b, m[i + 11], 16, 1839030562);
        b = md5hh(b, c, d, a, m[i + 14], 23, -35309556);
        a = md5hh(a, b, c, d, m[i + 1], 4, -1530992060);
        d = md5hh(d, a, b, c, m[i + 4], 11, 1272893353);
        c = md5hh(c, d, a, b, m[i + 7], 16, -155497632);
        b = md5hh(b, c, d, a, m[i + 10], 23, -1094730640);
        a = md5hh(a, b, c, d, m[i + 13], 4, 681279174);
        d = md5hh(d, a, b, c, m[i], 11, -358537222);
        c = md5hh(c, d, a, b, m[i + 3], 16, -722521979);
        b = md5hh(b, c, d, a, m[i + 6], 23, 76029189);
        a = md5hh(a, b, c, d, m[i + 9], 4, -640364487);
        d = md5hh(d, a, b, c, m[i + 12], 11, -421815835);
        c = md5hh(c, d, a, b, m[i + 15], 16, 530742520);
        b = md5hh(b, c, d, a, m[i + 2], 23, -995338651);
        a = md5ii(a, b, c, d, m[i], 6, -198630844);
        d = md5ii(d, a, b, c, m[i + 7], 10, 1126891415);
        c = md5ii(c, d, a, b, m[i + 14], 15, -1416354905);
        b = md5ii(b, c, d, a, m[i + 5], 21, -57434055);
        a = md5ii(a, b, c, d, m[i + 12], 6, 1700485571);
        d = md5ii(d, a, b, c, m[i + 3], 10, -1894986606);
        c = md5ii(c, d, a, b, m[i + 10], 15, -1051523);
        b = md5ii(b, c, d, a, m[i + 1], 21, -2054922799);
        a = md5ii(a, b, c, d, m[i + 8], 6, 1873313359);
        d = md5ii(d, a, b, c, m[i + 15], 10, -30611744);
        c = md5ii(c, d, a, b, m[i + 6], 15, -1560198380);
        b = md5ii(b, c, d, a, m[i + 13], 21, 1309151649);
        a = md5ii(a, b, c, d, m[i + 4], 6, -145523070);
        d = md5ii(d, a, b, c, m[i + 11], 10, -1120210379);
        c = md5ii(c, d, a, b, m[i + 2], 15, 718787259);
        b = md5ii(b, c, d, a, m[i + 9], 21, -343485551);
        a = safeAdd(a, olda); b = safeAdd(b, oldb);
        c = safeAdd(c, oldc); d = safeAdd(d, oldd);
    }

    function hex32(val) {
        var str = '';
        for (var j = 0; j < 4; j++) {
            var byte_ = (val >>> (j * 8)) & 0xFF;
            var h = byte_.toString(16);
            if (h.length < 2) h = '0' + h;
            str += h;
        }
        return str;
    }
    return hex32(a) + hex32(b) + hex32(c) + hex32(d);
}
