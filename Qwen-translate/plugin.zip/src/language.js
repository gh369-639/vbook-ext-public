// language.js
// Entry point cho cấu hình ngôn ngữ của plugin

var source_language = "zh_CN";
var target_language = "vi_VN";
var support_auto_detect = true;
