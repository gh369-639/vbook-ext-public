// baidutranslate.js
// Dịch bằng Baidu Translate API (dùng làm fallback)

var BAIDU_API_URL = 'https://fanyi-api.baidu.com/api/trans/vip/translate';

async function translateWithBaidu(text, fromLang, toLang) {
    var appid  = getConfig('baidu_appid', '');
    var appkey = getConfig('baidu_key', '');

    if (!appid || !appkey) {
        throw new Error('Baidu: Chưa cấu hình baidu_appid và baidu_key');
    }

    var from = getBaiduLangCode(fromLang || 'auto');
    var to   = getBaiduLangCode(toLang  || 'vi_VN');
    var salt = String(Date.now());
    var sign = md5(appid + text + salt + appkey);

    var body = 'q='     + encodeURIComponent(text) +
               '&from=' + encodeURIComponent(from) +
               '&to='   + encodeURIComponent(to)   +
               '&appid='+ encodeURIComponent(appid) +
               '&salt=' + encodeURIComponent(salt) +
               '&sign=' + encodeURIComponent(sign);

    var response = await fetch(BAIDU_API_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: body
    });

    var data;
    try {
        data = JSON.parse(await response.text());
    } catch(e) {
        throw new Error('Baidu: Phản hồi không hợp lệ');
    }

    if (data.error_code) {
        throw new Error('Baidu lỗi ' + data.error_code + ': ' + (data.error_msg || ''));
    }

    if (!data.trans_result || data.trans_result.length === 0) {
        throw new Error('Baidu: Không có kết quả dịch');
    }

    return data.trans_result.map(function(r) { return r.dst; }).join('\n');
}
