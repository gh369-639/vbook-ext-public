// modalBaidu_Edge.js
// Hàm hỗ trợ hiển thị thông báo trạng thái Baidu/Edge

function getBaiduStatus() {
    var appid  = getConfig('baidu_appid', '');
    var appkey = getConfig('baidu_key', '');
    if (appid && appkey) {
        return 'Baidu: ✓ Đã cấu hình (appid: ' + appid.substring(0, 4) + '***)';
    }
    return 'Baidu: ✗ Chưa cấu hình (cần baidu_appid + baidu_key)';
}

function getEdgeStatus() {
    var key = getConfig('edge_key', '');
    if (key) {
        return 'Edge Translate: ✓ Đã cấu hình';
    }
    return 'Edge Translate: ✗ Chưa cấu hình (cần edge_key)';
}

function getFallbackStatus() {
    return getBaiduStatus() + '\n' + getEdgeStatus();
}
