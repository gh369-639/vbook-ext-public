// creat_prompt_name.js
// Tạo prompt dựa trên phân tích tên nhân vật và thể loại truyện

// Tạo prompt tự động bằng model_Creat_Prompt
async function autoCreatePrompt(sampleText, apiKeys, models) {
    if (!sampleText || !apiKeys || apiKeys.length === 0) return null;
    if (!models || models.length === 0) return null;

    var request = buildCreatePromptRequest(sampleText, null);
    var messages = [
        { role: 'user', content: request }
    ];

    var opts = {
        temperature: 0.7,
        topP: 0.9,
        topK: 20
    };

    try {
        var result = await callQwenWithRetry(messages, models, apiKeys, opts);
        if (result && result.content) {
            return result.content.trim();
        }
    } catch(e) {
        // Tạo prompt thất bại, dùng prompt mặc định
    }
    return null;
}

// Tạo prompt có kèm danh sách tên từ chương đầu
async function createPromptWithNames(chapterText, apiKeys, models) {
    var useLocName = parseInt2(getConfig('use_loc_name', 2), 2);

    // Trích xuất tên ứng viên
    var nameCandidates = useLocName === 1 ? extractNameCandidates(chapterText) : {};

    // Xây dựng system prompt
    var prompt = buildSystemPrompt(nameCandidates);

    // Cache prompt nếu có tên prompt trong config
    var listprompts = parseLines(getConfig('listprompts', ''));
    if (listprompts.length > 0) {
        setPromptCache(listprompts[0], prompt);
    }

    return prompt;
}

// Dịch tự động (dùng model_Auto_Trans)
async function autoTranslate(text, apiKeys) {
    var models = parseLines(getConfig('model_Auto_Trans', 'qwen-plus'));
    if (models.length === 0) models = ['qwen-plus'];

    var prompt = buildSystemPrompt({});
    var messages = [
        { role: 'system', content: prompt },
        { role: 'user', content: text }
    ];

    var opts = {
        temperature: parseNum(getConfig('temp', 0.5), 0.5),
        topP:        parseNum(getConfig('topP', 0.5), 0.5),
        topK:        parseInt2(getConfig('topK', 20), 20)
    };

    var result = await callQwenWithRetry(messages, models, apiKeys, opts);
    return result ? result.content : null;
}
