// language_list.js
// Danh sách ngôn ngữ hỗ trợ

var LANGUAGE_LIST = [
    { code: "auto", name: "Tự động phát hiện" },
    { code: "zh_CN", name: "Tiếng Trung (Giản thể)" },
    { code: "zh_TW", name: "Tiếng Trung (Phồn thể)" },
    { code: "vi_VN", name: "Tiếng Việt" },
    { code: "en", name: "Tiếng Anh" },
    { code: "ja", name: "Tiếng Nhật" },
    { code: "ko", name: "Tiếng Hàn" },
    { code: "fr", name: "Tiếng Pháp" },
    { code: "de", name: "Tiếng Đức" },
    { code: "es", name: "Tiếng Tây Ban Nha" },
    { code: "pt", name: "Tiếng Bồ Đào Nha" },
    { code: "ru", name: "Tiếng Nga" },
    { code: "ar", name: "Tiếng Ả Rập" },
    { code: "th", name: "Tiếng Thái" },
    { code: "id", name: "Tiếng Indonesia" }
];

// Map từ code VBook sang Qwen language tag
var LANG_CODE_TO_QWEN = {
    "auto":  "auto",
    "zh_CN": "Chinese Simplified",
    "zh_TW": "Chinese Traditional",
    "vi_VN": "Vietnamese",
    "en":    "English",
    "ja":    "Japanese",
    "ko":    "Korean",
    "fr":    "French",
    "de":    "German",
    "es":    "Spanish",
    "pt":    "Portuguese",
    "ru":    "Russian",
    "ar":    "Arabic",
    "th":    "Thai",
    "id":    "Indonesian"
};

// Map sang Baidu language code
var LANG_CODE_TO_BAIDU = {
    "auto":  "auto",
    "zh_CN": "zh",
    "zh_TW": "cht",
    "vi_VN": "vie",
    "en":    "en",
    "ja":    "jp",
    "ko":    "kor",
    "fr":    "fra",
    "de":    "de",
    "es":    "spa",
    "pt":    "pt",
    "ru":    "ru",
    "ar":    "ara",
    "th":    "th",
    "id":    "id"
};

function getLangName(code) {
    return LANG_CODE_TO_QWEN[code] || code;
}

function getBaiduLangCode(code) {
    return LANG_CODE_TO_BAIDU[code] || "auto";
}
