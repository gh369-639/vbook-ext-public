// edge_trans.js
// Dịch bằng Microsoft Edge/Bing Translate (dùng làm fallback thứ hai)

var EDGE_TRANS_URL = 'https://api.cognitive.microsofttranslator.com/translate';

// Map sang Microsoft language code
var LANG_CODE_TO_EDGE = {
    "auto":  "zh-Hans",
    "zh_CN": "zh-Hans",
    "zh_TW": "zh-Hant",
    "vi_VN": "vi",
    "en":    "en",
    "ja":    "ja",
    "ko":    "ko",
    "fr":    "fr",
    "de":    "de",
    "es":    "es",
    "pt":    "pt",
    "ru":    "ru",
    "ar":    "ar",
    "th":    "th",
    "id":    "id"
};

function getEdgeLangCode(code) {
    return LANG_CODE_TO_EDGE[code] || 'zh-Hans';
}

async function translateWithEdge(text, fromLang, toLang) {
    var apiKey = getConfig('edge_key', '');
    var region = getConfig('edge_region', 'eastasia');

    if (!apiKey) {
        throw new Error('Edge Translate: Chưa cấu hình edge_key');
    }

    var to   = getEdgeLangCode(toLang || 'vi_VN');
    var from = (fromLang && fromLang !== 'auto') ? getEdgeLangCode(fromLang) : undefined;

    var url = EDGE_TRANS_URL + '?api-version=3.0&to=' + encodeURIComponent(to);
    if (from) url += '&from=' + encodeURIComponent(from);

    var response = await fetch(url, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Ocp-Apim-Subscription-Key': apiKey,
            'Ocp-Apim-Subscription-Region': region
        },
        body: JSON.stringify([{ Text: text }])
    });

    var data;
    try {
        data = JSON.parse(await response.text());
    } catch(e) {
        throw new Error('Edge Translate: Phản hồi không hợp lệ');
    }

    if (!response.ok) {
        var errMsg = (data.error && data.error.message) || response.status;
        throw new Error('Edge Translate lỗi: ' + errMsg);
    }

    if (!data || !data[0] || !data[0].translations || data[0].translations.length === 0) {
        throw new Error('Edge Translate: Không có kết quả dịch');
    }

    return data[0].translations[0].text;
}
