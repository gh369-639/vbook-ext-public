// mng_Qwen_trans.js
// Quản lý gọi API Qwen (Alibaba DashScope) - thay thế mng_Gemini_trans.js
// Sử dụng endpoint tương thích OpenAI của DashScope

var QWEN_API_URL = 'https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions';

// ─── Gọi API Qwen một lần ────────────────────────────────────────────────────

async function callQwenAPI(messages, model, apiKey, opts) {
    var temperature = parseNum(opts && opts.temperature, 0.5);
    var topP        = parseNum(opts && opts.topP, 0.5);
    var topK        = parseInt2(opts && opts.topK, 20);

    var body = {
        model:       model,
        messages:    messages,
        temperature: temperature,
        top_p:       topP,
        stream:      false
    };

    // Qwen hỗ trợ top_k như một tham số mở rộng
    if (topK > 0) body.top_k = topK;

    var response = await fetch(QWEN_API_URL, {
        method: 'POST',
        headers: {
            'Content-Type':  'application/json',
            'Authorization': 'Bearer ' + apiKey
        },
        body: JSON.stringify(body)
    });

    var rawText = await response.text();
    var data;
    try {
        data = JSON.parse(rawText);
    } catch(e) {
        throw new Error('Qwen: Phản hồi không hợp lệ JSON: ' + rawText.substring(0, 200));
    }

    // Xử lý lỗi HTTP
    if (!response.ok) {
        var errMsg = (data && data.error && data.error.message) || rawText.substring(0, 300);
        var code   = response.status;

        if (code === 401 || code === 403) {
            throw { keyDead: true, type: 'auth',
                    message: 'Qwen key lỗi xác thực (HTTP ' + code + '): ' + errMsg };
        }
        if (code === 429) {
            throw { keyDead: true, type: 'rate_limit',
                    message: 'Qwen rate limit (HTTP 429): ' + errMsg };
        }
        if (code === 400) {
            throw new Error('Qwen yêu cầu không hợp lệ (HTTP 400): ' + errMsg);
        }
        throw new Error('Qwen HTTP ' + code + ': ' + errMsg);
    }

    // Xử lý lỗi trong body
    if (data && data.error) {
        var ec = String(data.error.code || '').toLowerCase();
        if (ec.includes('invalid_api_key') || ec.includes('authentication') || ec.includes('unauthorized')) {
            throw { keyDead: true, type: 'auth',
                    message: 'Qwen key không hợp lệ: ' + data.error.message };
        }
        if (ec.includes('rate') || ec.includes('quota') || ec.includes('throttl')) {
            throw { keyDead: true, type: 'rate_limit',
                    message: 'Qwen quota/rate limit: ' + data.error.message };
        }
        throw new Error('Qwen API lỗi [' + (data.error.code || '') + ']: ' + data.error.message);
    }

    if (!data || !data.choices || data.choices.length === 0) {
        throw new Error('Qwen: Không có nội dung trong phản hồi');
    }

    var content = data.choices[0].message && data.choices[0].message.content;
    if (content === null || content === undefined) {
        throw new Error('Qwen: Nội dung phản hồi trống');
    }

    return {
        content:     content.trim(),
        model:       data.model || model,
        inputTokens: (data.usage && data.usage.prompt_tokens) || 0,
        outTokens:   (data.usage && data.usage.completion_tokens) || 0
    };
}

// ─── Gọi Qwen với xoay vòng model và key ────────────────────────────────────

async function callQwenWithRetry(messages, models, apiKeys, opts) {
    var lastError = null;

    for (var m = 0; m < models.length; m++) {
        var model = models[m] && models[m].trim();
        if (!model) continue;

        var available = getAvailableKeys(apiKeys);
        if (available.length === 0) break;

        for (var k = 0; k < available.length; k++) {
            var key = available[k];
            try {
                var result = await callQwenAPI(messages, model, key, opts);
                markKeySuccess(key);
                return result;
            } catch(err) {
                if (err && err.keyDead) {
                    markKeyDead(key, err.type || 'error');
                    lastError = err;
                    // Thử key tiếp theo
                } else {
                    lastError = err;
                    // Lỗi không liên quan đến key → thử model tiếp theo
                    break;
                }
            }
        }
        // Hết key hoặc lỗi model → thử model tiếp theo
    }

    throw lastError || new Error('Qwen: Tất cả model và key đều thất bại');
}

// ─── Dịch một chunk văn bản ──────────────────────────────────────────────────

async function translateChunkWithQwen(chunkText, systemPrompt, models, apiKeys, opts) {
    var messages = [
        { role: 'system', content: systemPrompt },
        { role: 'user',   content: chunkText }
    ];
    var result = await callQwenWithRetry(messages, models, apiKeys, opts);
    return result.content;
}

// ─── Thông tin trạng thái API ────────────────────────────────────────────────

function getQwenStatus(apiKeys) {
    var total   = apiKeys.length;
    var dead    = apiKeys.filter(function(k) { return k && isKeyDead(k); }).length;
    var limited = apiKeys.filter(function(k) { return k && isKeyRateLimited(k); }).length;
    var active  = total - dead;
    return 'Qwen keys: ' + active + '/' + total + ' hoạt động' +
           (limited > 0 ? ', ' + limited + ' rate limit' : '') +
           (dead    > 0 ? ', ' + dead    + ' dead'       : '');
}
