// phienam.js
// Xử lý phiên âm và lọc tên nhân vật tiếng Trung/Hán-Việt

// Bảng phiên âm Hán-Việt cơ bản (ký tự Hán → Hán Việt)
// Chỉ bao gồm các ký tự phổ biến nhất trong tiểu thuyết
var HAN_VIET_MAP = {
    '王': 'Vương', '李': 'Lý', '张': 'Trương', '刘': 'Lưu', '陈': 'Trần',
    '杨': 'Dương', '赵': 'Triệu', '黄': 'Hoàng', '周': 'Chu', '吴': 'Ngô',
    '徐': 'Từ', '孙': 'Tôn', '朱': 'Chu', '马': 'Mã', '胡': 'Hồ',
    '郭': 'Quách', '林': 'Lâm', '何': 'Hà', '高': 'Cao', '罗': 'La',
    '郑': 'Trịnh', '梁': 'Lương', '谢': 'Tạ', '宋': 'Tống', '唐': 'Đường',
    '许': 'Hứa', '邓': 'Đặng', '冯': 'Phùng', '韩': 'Hàn', '曹': 'Tào',
    '秦': 'Tần', '魏': 'Ngụy', '薛': 'Tiết', '蒋': 'Tưởng', '叶': 'Diệp',
    '苏': 'Tô', '魏': 'Ngụy', '江': 'Giang', '白': 'Bạch', '丁': 'Đinh',
    '方': 'Phương', '石': 'Thạch', '沈': 'Thẩm', '程': 'Trình', '武': 'Vũ',
    '傅': 'Phó', '彭': 'Bành', '卢': 'Lư', '蔡': 'Thái', '汪': 'Uông',
    '龙': 'Long', '凤': 'Phụng', '天': 'Thiên', '地': 'Địa', '人': 'Nhân',
    '神': 'Thần', '魔': 'Ma', '仙': 'Tiên', '皇': 'Hoàng', '帝': 'Đế',
    '圣': 'Thánh', '武': 'Vũ', '文': 'Văn', '道': 'Đạo', '剑': 'Kiếm',
    '云': 'Vân', '雪': 'Tuyết', '风': 'Phong', '月': 'Nguyệt', '星': 'Tinh',
    '宇': 'Vũ', '辰': 'Thần', '阳': 'Dương', '阴': 'Âm', '灵': 'Linh',
    '心': 'Tâm', '真': 'Chân', '一': 'Nhất', '三': 'Tam', '九': 'Cửu'
};

// Lấy phiên âm Hán-Việt của một chuỗi ký tự Hán
function getHanViet(hanzi) {
    var result = '';
    for (var i = 0; i < hanzi.length; i++) {
        var char = hanzi[i];
        result += (HAN_VIET_MAP[char] || char);
        if (i < hanzi.length - 1) result += ' ';
    }
    return result;
}

// Kiểm tra xem một chuỗi có phải là tên riêng (toàn ký tự Hán) không
function isChineseNameCandidate(str) {
    return /^[\u4e00-\u9fff]{2,6}$/.test(str);
}

// Tạo phiên âm Hán-Việt cho danh sách tên
function buildPhienamDict(names) {
    var dict = {};
    for (var i = 0; i < names.length; i++) {
        var name = names[i];
        if (isChineseNameCandidate(name)) {
            dict[name] = getHanViet(name);
        }
    }
    return dict;
}

// Áp dụng phiên âm vào văn bản đã dịch (thay thế tên chưa được dịch)
function applyPhienam(translatedText, namePhienamDict) {
    var text = translatedText;
    for (var name in namePhienamDict) {
        if (namePhienamDict.hasOwnProperty(name)) {
            // Chỉ thay thế nếu tên gốc còn xuất hiện trong bản dịch
            var regex = new RegExp(name.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'g');
            text = text.replace(regex, namePhienamDict[name]);
        }
    }
    return text;
}
