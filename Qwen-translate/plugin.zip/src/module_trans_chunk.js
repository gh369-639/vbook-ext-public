// module_trans_chunk.js
// Chia văn bản thành các chunk để dịch, tránh vượt quá giới hạn token

// Chia text thành mảng chunk theo số ký tự tối đa
function splitIntoChunks(text, maxLength) {
    if (!maxLength || maxLength <= 0) return [text];
    if (!text || text.length <= maxLength) return [text];

    var chunks = [];
    var lines  = text.split('\n');
    var current = '';

    for (var i = 0; i < lines.length; i++) {
        var line = lines[i];

        // Nếu một dòng đơn lẻ đã dài hơn maxLength, chia theo câu
        if (line.length > maxLength) {
            // Flush chunk hiện tại trước
            if (current.trim()) {
                chunks.push(current);
                current = '';
            }
            // Chia dòng dài theo dấu câu
            var subChunks = splitLongLine(line, maxLength);
            chunks = chunks.concat(subChunks);
            continue;
        }

        var candidate = current ? current + '\n' + line : line;

        if (candidate.length > maxLength) {
            // Flush chunk hiện tại
            if (current.trim()) chunks.push(current);
            current = line;
        } else {
            current = candidate;
        }
    }

    if (current.trim()) chunks.push(current);
    return chunks;
}

// Chia một dòng dài theo dấu câu
function splitLongLine(line, maxLength) {
    var result = [];
    // Chia theo dấu câu CJK và Latin
    var sentences = line.match(/[^。！？.!?\n]+[。！？.!?]?/g) || [line];
    var current = '';

    for (var i = 0; i < sentences.length; i++) {
        var s = sentences[i];
        var candidate = current ? current + s : s;
        if (candidate.length > maxLength && current) {
            result.push(current);
            current = s;
        } else {
            current = candidate;
        }
    }
    if (current) result.push(current);
    return result.length > 0 ? result : [line];
}

// Nối các chunk đã dịch lại
function joinChunks(translatedChunks, originalChunks) {
    // Giữ đúng cấu trúc xuống dòng của từng chunk
    return translatedChunks.join('\n');
}

// Kiểm tra xem có cần chia chunk không
function needsChunking(text, maxLength) {
    return maxLength > 0 && text.length > maxLength;
}
