// mng_key_die.js
// Quản lý trạng thái API key - đánh dấu key lỗi và xoay vòng key

var _keyFailCount = {};
var _keyLastFail = {};
var _keyRateLimit = {};

// Đánh dấu key bị lỗi
function markKeyDead(key, errorType) {
    _keyFailCount[key] = (_keyFailCount[key] || 0) + 1;
    _keyLastFail[key] = Date.now();
    if (errorType === 'rate_limit') {
        // Rate limit: chờ 60 giây trước khi thử lại
        _keyRateLimit[key] = Date.now() + 60000;
    }
}

// Kiểm tra key có bị dead không
function isKeyDead(key) {
    var fails = _keyFailCount[key] || 0;
    if (fails < 3) return false;

    var lastFail = _keyLastFail[key] || 0;
    // Reset sau 10 phút
    if (Date.now() - lastFail > 600000) {
        _keyFailCount[key] = 0;
        _keyRateLimit[key] = 0;
        return false;
    }
    return true;
}

// Kiểm tra key có đang bị rate limit không
function isKeyRateLimited(key) {
    var until = _keyRateLimit[key] || 0;
    return Date.now() < until;
}

// Lấy danh sách key khả dụng
function getAvailableKeys(keys) {
    var available = keys.filter(function(k) {
        return k && k.trim() && !isKeyDead(k) && !isKeyRateLimited(k);
    });

    if (available.length === 0) {
        // Thử lại với key chưa dead (bỏ qua rate limit)
        available = keys.filter(function(k) {
            return k && k.trim() && !isKeyDead(k);
        });
    }

    if (available.length === 0) {
        // Reset tất cả key nếu tất cả đều dead
        _keyFailCount = {};
        _keyRateLimit = {};
        available = keys.filter(function(k) { return k && k.trim(); });
    }

    return available;
}

// Reset trạng thái key thành công
function markKeySuccess(key) {
    _keyFailCount[key] = 0;
    _keyRateLimit[key] = 0;
}
