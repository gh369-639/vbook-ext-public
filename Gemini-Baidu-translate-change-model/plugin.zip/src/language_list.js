let languages = [
    {"id": "gemini-2.0-flash", "name": "Model: 2.0 Flash"},
    {"id": "gemini-2.0-flash-lite", "name": "Model: 2.0 Flash lite"},
    {"id": "gemini-2.5-pro", "name": "Model: 2.5 Pro"},
    {"id": "gemini-2.5-flash-preview-05-20", "name": "Model: 2.5 Flash Preview"},
    {"id": "gemini-2.5-flash", "name": "Model: 2.5 Flash"},
    {"id": "gemini-2.5-flash-lite", "name": "Model: 2.5 Flash Lite"},
    {"id": "zh", "name": "Trung"},
    {"id": "en", "name": "Anh"},
    {"id": "vi", "name": "Việt"},
    {"id": "vi_tieuchuan", "name": "Việt (Tiêu chuẩn)"},
    {"id": "vi_NameEng", "name": "Việt (Name English)"},
    {"id": "vi_sac", "name": "Truyện Sắc"},
    {"id": "vi_vietlai", "name": "Viết Lại Convert"},
    {"id": "vi_tuychon1", "name": "Dùng prompt tùy chọn 1"},
    {"id": "vi_tuychon2", "name": "Dùng prompt tùy chọn 2"},
    {"id": "vi_xoacache", "name": "Xóa Cache Chương Này"}
];